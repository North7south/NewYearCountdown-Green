(function countdown() {
  const elD = document.getElementById("d");
  const elH = document.getElementById("h");
  const elM = document.getElementById("m");
  const elS = document.getElementById("s");
  const heading = document.getElementById("heading");
  if (!elD || !heading) return;

  function pad(n) {
    return String(n).padStart(2, "0");
  }

  function nextJanuaryFirstAfter(when) {
    let y = when.getFullYear();
    let t = new Date(y, 0, 1, 0, 0, 0, 0);
    while (t.getTime() <= when.getTime()) {
      y += 1;
      t = new Date(y, 0, 1, 0, 0, 0, 0);
    }
    return t;
  }

  function tick() {
    const now = new Date();
    const target = nextJanuaryFirstAfter(now);
    heading.textContent = "New Year · " + target.getFullYear();

    const diff = target.getTime() - now.getTime();
    const s = Math.floor(Math.max(0, diff) / 1000) % 60;
    const m = Math.floor(Math.max(0, diff) / 60000) % 60;
    const h = Math.floor(Math.max(0, diff) / 3600000) % 24;
    const d = Math.floor(Math.max(0, diff) / 86400000);
    elD.textContent = String(d);
    elH.textContent = pad(h);
    elM.textContent = pad(m);
    elS.textContent = pad(s);
  }

  tick();
  setInterval(tick, 1000);
})();

/**
 * Aerial shell: festive multicolour (coral, gold, lavender) — pops on deep green UI.
 * Canvas z10 (CSS); full bloom + staggered waves; gravity + drag.
 */
(function bloomFireworks() {
  const canvas = document.getElementById("blooms");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let w = 0;
  let h = 0;
  let dpr = 1;

  function resize() {
    dpr = window.devicePixelRatio || 1;
    w = canvas.width = Math.floor(window.innerWidth * dpr);
    h = canvas.height = Math.floor(window.innerHeight * dpr);
    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";
  }

  /** Per-show themes: coral, gold, rose, cool accents — full colour fireworks (no green-only shells). */
  const SHELL_THEMES = [
    [
      [255, 228, 210],
      [248, 198, 175],
      [232, 150, 155],
      [210, 118, 128],
      [255, 212, 175],
      [196, 132, 148],
    ],
    [
      [255, 236, 218],
      [255, 210, 165],
      [238, 175, 140],
      [220, 145, 125],
      [200, 125, 138],
      [255, 200, 185],
    ],
    [
      [245, 225, 235],
      [228, 185, 205],
      [210, 145, 168],
      [255, 218, 205],
      [190, 155, 175],
      [235, 200, 215],
    ],
    [
      [255, 230, 150],
      [255, 200, 120],
      [200, 175, 255],
      [165, 210, 255],
      [255, 180, 200],
      [180, 220, 255],
    ],
  ];
  const GOLDEN = Math.PI * (3 - Math.sqrt(5));

  function pickTheme() {
    return SHELL_THEMES[(Math.random() * SHELL_THEMES.length) | 0];
  }

  function pickBloomColor(pal) {
    const p = pal && pal.length ? pal : SHELL_THEMES[0];
    return p[(Math.random() * p.length) | 0];
  }

  function rgbToHsv(r, g, b) {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const d = max - min;
    let h = 0;
    const s = max === 0 ? 0 : d / max;
    const v = max;
    if (d > 1e-6) {
      if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
      else if (max === g) h = ((b - r) / d + 2) / 6;
      else h = ((r - g) / d + 4) / 6;
    }
    return [h, s, v];
  }

  function hsvToRgb(h, s, v) {
    const i = Math.floor(h * 6);
    const f = h * 6 - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    let rn;
    let gn;
    let bn;
    switch (i % 6) {
      case 0:
        rn = v;
        gn = t;
        bn = p;
        break;
      case 1:
        rn = q;
        gn = v;
        bn = p;
        break;
      case 2:
        rn = p;
        gn = v;
        bn = t;
        break;
      case 3:
        rn = p;
        gn = q;
        bn = v;
        break;
      case 4:
        rn = t;
        gn = p;
        bn = v;
        break;
      default:
        rn = v;
        gn = p;
        bn = q;
        break;
    }
    return [
      Math.min(255, Math.round(rn * 255)),
      Math.min(255, Math.round(gn * 255)),
      Math.min(255, Math.round(bn * 255)),
    ];
  }

  /** Jewel-like but soft: no full neon; reads on deep green UI. */
  function softShellRgb(r, g, b) {
    let [hue, s, v] = rgbToHsv(r, g, b);
    s = Math.min(0.82, Math.max(0.42, s * 0.88 + 0.06));
    v = Math.min(0.99, Math.max(0.84, v * 0.96 + 0.04));
    return hsvToRgb(hue, s, v);
  }

  function rgbAlongTrail(cr, cg, cb, t) {
    const [hue, s0] = rgbToHsv(cr, cg, cb);
    const tail = 1 - t;
    const s = Math.min(0.72, Math.max(0.22, s0 * (0.55 + 0.38 * t + 0.12 * tail)));
    const v = Math.min(1, 0.68 + 0.26 * t + 0.08 * (1 - tail));
    return hsvToRgb(hue, s, v);
  }

  function createStreamParticle(cx, cy, ang, speed, maxLife, trailMax, headScale, colorRgb, themePal) {
    const raw = colorRgb != null ? colorRgb : pickBloomColor(themePal);
    const rgb = softShellRgb(raw[0], raw[1], raw[2]);
    headScale = headScale == null ? 1 : headScale;
    const j = 7 * dpr;
    const sx = cx + (Math.random() - 0.5) * j;
    const sy = cy + (Math.random() - 0.5) * j;
    return {
      x: sx,
      y: sy,
      vx: Math.cos(ang) * speed,
      vy: Math.sin(ang) * speed,
      cr: rgb[0],
      cg: rgb[1],
      cb: rgb[2],
      trail: [],
      age: 0,
      maxLife,
      tw: Math.random() * Math.PI * 2,
      rHead: (1.55 + Math.random() * 1.85) * dpr * headScale,
      trailMax,
    };
  }

  function spawnBloomCore(cx, cy, pal) {
    const out = [];
    const base = Math.random() * Math.PI * 2;
    const colorBase = (Math.random() * pal.length) | 0;
    const n = 40 + ((Math.random() * 20) | 0);
    for (let i = 0; i < n; i++) {
      const ang =
        base +
        i * GOLDEN +
        (Math.random() - 0.5) * 0.48 +
        Math.sin(i * 0.37 + base * 2) * 0.14;
      const speedT = Math.pow(Math.random(), 0.5);
      const sp = (88 + speedT * 258) * dpr;
      const life = 2550 + Math.random() * 1500 + speedT * 650;
      const raw = pal[(colorBase + i * 7) % pal.length];
      out.push(createStreamParticle(cx, cy, ang, sp, life, 62, 0.88 + Math.random() * 0.22, raw, pal));
    }
    return out;
  }

  function spawnBloomVeil(cx, cy, pal) {
    const out = [];
    const base = Math.random() * Math.PI * 2;
    const colorBase = (Math.random() * pal.length) | 0;
    const n = 15 + ((Math.random() * 12) | 0);
    for (let i = 0; i < n; i++) {
      const ang =
        base + (i / n) * Math.PI * 2 + (Math.random() - 0.5) * 0.62 + Math.sin(i * 0.9) * 0.18;
      const sp = (58 + Math.pow(Math.random(), 0.72) * 138) * dpr;
      const raw = pal[(colorBase + i * 5 + 3) % pal.length];
      out.push(createStreamParticle(cx, cy, ang, sp, 2200 + Math.random() * 950, 52, 0.62 + Math.random() * 0.18, raw, pal));
    }
    return out;
  }

  function spawnBloomEmbers(cx, cy, pal) {
    const out = [];
    const base = Math.random() * Math.PI * 2;
    const colorBase = (Math.random() * pal.length) | 0;
    const n = 10 + ((Math.random() * 9) | 0);
    for (let i = 0; i < n; i++) {
      const ang = base + i * GOLDEN * 1.27 + (Math.random() - 0.5) * 0.95;
      const sp = (42 + Math.random() * 92) * dpr;
      const raw = pal[(colorBase + i * 11 + 5) % pal.length];
      out.push(createStreamParticle(cx, cy, ang, sp, 1300 + Math.random() * 800, 40, 0.42 + Math.random() * 0.16, raw, pal));
    }
    return out;
  }

  function spawnCrackle(cx, cy, pal) {
    const out = [];
    const base = Math.random() * Math.PI * 2;
    const colorBase = (Math.random() * pal.length) | 0;
    const n = 14 + ((Math.random() * 10) | 0);
    for (let i = 0; i < n; i++) {
      const ang = base + i * GOLDEN + (Math.random() - 0.5) * 0.55;
      const sp = (48 + Math.random() * 100) * dpr;
      const raw = pal[(colorBase + i * 3 + 9) % pal.length];
      out.push(createStreamParticle(cx, cy, ang, sp, 820 + Math.random() * 480, 30, 0.3, raw, pal));
    }
    return out;
  }

  function allParticlesDone(f) {
    const wavesOk = !f.pendingWaves || f.pendingWaves.every((w) => w.done);
    const main =
      f.particles.length === 0 || f.particles.every((p) => p.age >= p.maxLife);
    const crack =
      f.crackle.length === 0 || f.crackle.every((p) => p.age >= p.maxLife * 0.88);
    return wavesOk && main && crack;
  }

  function pickBurstSite() {
    const mx = 0.5 * w;
    const my = 0.46 * h;
    const rx = 0.38 * w;
    const ry = 0.44 * h;
    for (let tries = 0; tries < 90; tries++) {
      const cx = (0.06 + Math.random() * 0.88) * w;
      const apex = (0.05 + Math.random() * 0.78) * h;
      const dx = (cx - mx) / rx;
      const dy = (apex - my) / ry;
      if (dx * dx + dy * dy > 1) {
        return { cx, apex };
      }
    }
    const corners = [
      [0.14, 0.16],
      [0.86, 0.18],
      [0.12, 0.82],
      [0.88, 0.8],
      [0.48, 0.1],
      [0.52, 0.9],
    ];
    const c = corners[(Math.random() * corners.length) | 0];
    return { cx: c[0] * w, apex: c[1] * h };
  }

  function makeShow() {
    const { cx, apex } = pickBurstSite();
    const rise = 380 + Math.random() * 220;
    const riseFrom = apex + (115 + Math.random() * 90) * dpr;
    return {
      phase: "rise",
      cx,
      apex,
      riseFrom,
      riseDur: rise,
      t: 0,
      prevRiseY: null,
      particles: [],
      crackle: [],
      crackleSpawned: false,
      flash: 0,
      burstX: 0,
      burstY: 0,
      burstRel: 0,
      pendingWaves: null,
      themePal: pickTheme(),
    };
  }

  function burstAt(f, x, y) {
    const pal = f.themePal;
    f.burstX = x;
    f.burstY = y;
    f.burstRel = 0;
    f.particles = spawnBloomCore(x, y, pal);
    f.pendingWaves = [
      { at: 48 + Math.random() * 52, done: false, gen: () => spawnBloomVeil(x, y, pal) },
      { at: 138 + Math.random() * 95, done: false, gen: () => spawnBloomEmbers(x, y, pal) },
    ];
    f.flash = 0.78;
  }

  function stepParticle(p, dt) {
    const sec = dt / 1000;
    p.age += dt;
    p.trail.push({ x: p.x, y: p.y });
    while (p.trail.length > p.trailMax) p.trail.shift();

    p.x += p.vx * sec;
    p.y += p.vy * sec;

    p.vy += 108 * dpr * sec;

    const v = Math.hypot(p.vx, p.vy);
    if (v > 0.32) {
      const k = 0.00168 * dpr;
      const damp = Math.exp(-k * v * sec);
      p.vx *= damp;
      p.vy *= damp;
    }

    p.vx += Math.sin(p.age * 0.00155 + p.tw) * (4.2 + p.age * 0.0048) * dpr * sec;
    p.vy += Math.cos(p.age * 0.00105 + p.tw * 1.12) * 1.15 * dpr * sec;
  }

  function envAlpha(p) {
    const k = p.age / p.maxLife;
    const rise = Math.min(1, p.age / 120);
    const fade = k < 0.04 ? 1 : Math.exp(-2.35 * (k - 0.04) / 0.96);
    return rise * fade;
  }

  function drawSparkHead(x, y, r, cr, cg, cb, a) {
    if (a < 0.02 || r < 0.28) return;
    const rayLen = r * 3.15;
    const thick = Math.max(0.35 * dpr, r * 0.09);
    const thin = Math.max(0.22 * dpr, r * 0.055);

    ctx.save();
    ctx.translate(x, y);
    ctx.globalAlpha = Math.min(1, a * 0.95);
    const rays = 10;
    for (let i = 0; i < rays; i++) {
      const ang = (i / rays) * Math.PI * 2;
      const c = Math.cos(ang);
      const si = Math.sin(ang);
      const g = ctx.createLinearGradient(0, 0, c * rayLen, si * rayLen);
      g.addColorStop(0, `rgba(255, 248, 242, ${0.42 * a})`);
      g.addColorStop(0.06, `rgba(${cr}, ${cg}, ${cb}, ${0.88 * a})`);
      g.addColorStop(0.28, `rgba(${cr}, ${cg}, ${cb}, ${0.45 * a})`);
      g.addColorStop(1, `rgba(${cr}, ${cg}, ${cb}, 0)`);
      ctx.strokeStyle = g;
      ctx.lineWidth = i % 2 === 0 ? thick : thin;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-c * r * 0.08, -si * r * 0.08);
      ctx.lineTo(c * rayLen, si * rayLen);
      ctx.stroke();
    }
    ctx.restore();

    const rad = ctx.createRadialGradient(x, y, 0, x, y, r);
    rad.addColorStop(0, `rgba(255, 252, 250, ${0.38 * a})`);
    rad.addColorStop(0.12, `rgba(${cr}, ${cg}, ${cb}, ${0.88 * a})`);
    rad.addColorStop(0.35, `rgba(${cr}, ${cg}, ${cb}, ${0.62 * a})`);
    rad.addColorStop(0.62, `rgba(${cr}, ${cg}, ${cb}, ${0.38 * a})`);
    rad.addColorStop(0.88, `rgba(${cr}, ${cg}, ${cb}, ${0.14 * a})`);
    rad.addColorStop(1, `rgba(${cr}, ${cg}, ${cb}, 0)`);
    ctx.fillStyle = rad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawVelocityTip(p, a) {
    const v = Math.hypot(p.vx, p.vy);
    if (v < 52 * dpr) return;
    const ux = p.vx / v;
    const uy = p.vy / v;
    const L = (2.4 + 1.9 * a) * dpr;
    ctx.lineCap = "round";
    ctx.strokeStyle = `rgba(${p.cr}, ${p.cg}, ${p.cb}, ${0.55 * a})`;
    ctx.lineWidth = Math.max(0.32 * dpr, 0.52 * dpr);
    ctx.beginPath();
    ctx.moveTo(p.x - ux * L, p.y - uy * L);
    ctx.lineTo(p.x - ux * L * 0.12, p.y - uy * L * 0.12);
    ctx.stroke();
    ctx.strokeStyle = `rgba(255, 250, 248, ${0.35 * a})`;
    ctx.lineWidth = 0.28 * dpr;
    ctx.beginPath();
    ctx.moveTo(p.x - ux * L * 1.02, p.y - uy * L * 1.02);
    ctx.lineTo(p.x - ux * L * 0.18, p.y - uy * L * 0.18);
    ctx.stroke();
  }

  function drawCrystalTrail(trail, hx, hy, cr, cg, cb, a) {
    const pts = trail.length ? trail.concat([{ x: hx, y: hy }]) : [{ x: hx, y: hy }];
    const n = pts.length;
    if (n < 2) return;

    function buildPath() {
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < n - 1; i++) {
        const xc = (pts[i].x + pts[i + 1].x) * 0.5;
        const yc = (pts[i].y + pts[i + 1].y) * 0.5;
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, xc, yc);
      }
      ctx.lineTo(pts[n - 1].x, pts[n - 1].y);
    }

    const x0 = pts[0].x;
    const y0 = pts[0].y;
    const x1 = pts[n - 1].x;
    const y1 = pts[n - 1].y;

    const [r0, g0, b0] = rgbAlongTrail(cr, cg, cb, 0.08);
    const [r3, g3, b3] = rgbAlongTrail(cr, cg, cb, 0.38);
    const [r6, g6, b6] = rgbAlongTrail(cr, cg, cb, 0.68);
    const [r1, g1, b1] = rgbAlongTrail(cr, cg, cb, 1);

    const gBody = ctx.createLinearGradient(x0, y0, x1, y1);
    gBody.addColorStop(0, `rgba(${r0}, ${g0}, ${b0}, 0)`);
    gBody.addColorStop(0.22, `rgba(${r3}, ${g3}, ${b3}, ${0.32 * a})`);
    gBody.addColorStop(0.52, `rgba(${r6}, ${g6}, ${b6}, ${0.52 * a})`);
    gBody.addColorStop(0.82, `rgba(${r1}, ${g1}, ${b1}, ${0.68 * a})`);
    gBody.addColorStop(1, `rgba(${r1}, ${g1}, ${b1}, ${0.78 * a})`);

    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = gBody;
    const wBody = (0.72 + 0.38 * a) * dpr;
    buildPath();
    ctx.lineWidth = wBody;
    ctx.globalAlpha = 0.9;
    ctx.stroke();

    const gSpine = ctx.createLinearGradient(x0, y0, x1, y1);
    gSpine.addColorStop(0, `rgba(${r0}, ${g0}, ${b0}, 0)`);
    gSpine.addColorStop(0.38, `rgba(${r3}, ${g3}, ${b3}, ${0.42 * a})`);
    gSpine.addColorStop(0.62, `rgba(${r6}, ${g6}, ${b6}, ${0.62 * a})`);
    gSpine.addColorStop(0.9, `rgba(${r1}, ${g1}, ${b1}, ${0.78 * a})`);
    gSpine.addColorStop(1, `rgba(255, 250, 248, ${0.55 * a})`);

    buildPath();
    ctx.strokeStyle = gSpine;
    ctx.lineWidth = Math.max(0.22 * dpr, (0.32 + 0.22 * a) * dpr);
    ctx.globalAlpha = 0.85;
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  function drawParticle(p) {
    const a = envAlpha(p);
    if (a < 0.02) return;
    drawCrystalTrail(p.trail, p.x, p.y, p.cr, p.cg, p.cb, a);
    drawVelocityTip(p, a);
    drawSparkHead(p.x, p.y, p.rHead * (1.05 + 0.35 * a), p.cr, p.cg, p.cb, a);
  }

  function drawFlashBloom(cx, cy, strength) {
    if (strength <= 0.02) return;
    const R = (14 + 28 * strength) * dpr;
    const rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
    rg.addColorStop(0, `rgba(255, 240, 232, ${0.2 * strength})`);
    rg.addColorStop(0.25, `rgba(245, 200, 188, ${0.11 * strength})`);
    rg.addColorStop(0.55, `rgba(210, 145, 150, ${0.05 * strength})`);
    rg.addColorStop(1, "rgba(120, 70, 78, 0)");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fill();
  }

  const shows = [];
  let last = 0;
  let nextAt = 0;

  function frame(now) {
    if (!last) last = now;
    const dt = Math.min(48, Math.max(1, now - last));
    last = now;

    ctx.clearRect(0, 0, w, h);
    ctx.globalCompositeOperation = shows.length > 0 ? "lighter" : "source-over";

    if (shows.length < 2 && now >= nextAt) {
      shows.push(makeShow());
      nextAt = now + 3000 + Math.random() * 3600;
    }

    for (let s = shows.length - 1; s >= 0; s--) {
      const f = shows[s];
      f.t += dt;

      if (f.phase === "rise") {
        const u = Math.min(1, f.t / f.riseDur);
        const ease = 1 - Math.pow(1 - u, 2.35);
        const py = f.riseFrom + (f.apex - f.riseFrom) * ease;
        const a = 0.34 + 0.32 * Math.sin(u * Math.PI);

        if (f.prevRiseY != null) {
          ctx.lineCap = "round";
          const gy = ctx.createLinearGradient(f.cx, f.prevRiseY, f.cx, py);
          gy.addColorStop(0, `rgba(255, 218, 195, ${a * 0.04})`);
          gy.addColorStop(0.5, `rgba(255, 185, 155, ${a * 0.12})`);
          gy.addColorStop(1, `rgba(255, 232, 210, ${a * 0.16})`);
          ctx.strokeStyle = gy;
          ctx.lineWidth = 0.95 * dpr;
          ctx.beginPath();
          ctx.moveTo(f.cx, f.prevRiseY);
          ctx.lineTo(f.cx, py);
          ctx.stroke();
        }
        f.prevRiseY = py;

        const headR = 2.35 * dpr;
        const rg = ctx.createRadialGradient(f.cx, py, 0, f.cx, py, headR * 1.85);
        rg.addColorStop(0, `rgba(255, 245, 228, ${a * 0.32})`);
        rg.addColorStop(0.4, `rgba(255, 200, 165, ${a * 0.12})`);
        rg.addColorStop(1, "rgba(235, 160, 140, 0)");
        ctx.fillStyle = rg;
        ctx.beginPath();
        ctx.arc(f.cx, py, headR * 1.85, 0, Math.PI * 2);
        ctx.fill();

        if (u >= 1) {
          f.phase = "burst";
          burstAt(f, f.cx, f.apex);
        }
      } else {
        f.burstRel += dt;
        if (f.pendingWaves) {
          for (const w of f.pendingWaves) {
            if (!w.done && f.burstRel >= w.at) {
              f.particles.push(...w.gen());
              w.done = true;
            }
          }
        }

        if (f.flash > 0) {
          drawFlashBloom(f.burstX, f.burstY, f.flash);
          f.flash = Math.max(0, f.flash - dt * 0.01);
        }

        if (!f.crackleSpawned && f.t > f.riseDur + 300) {
          f.crackle = spawnCrackle(f.cx, f.apex, f.themePal);
          f.crackleSpawned = true;
        }

        for (const p of f.particles) {
          if (p.age < p.maxLife) {
            stepParticle(p, dt);
            drawParticle(p);
          }
        }
        for (const p of f.crackle) {
          if (p.age < p.maxLife * 0.92) {
            stepParticle(p, dt);
            drawParticle(p);
          }
        }

        if (f.phase === "burst" && allParticlesDone(f) && f.t > f.riseDur + 350) {
          shows.splice(s, 1);
        }
      }
    }

    ctx.globalCompositeOperation = "source-over";
    requestAnimationFrame(frame);
  }

  window.addEventListener("resize", resize);
  function boot() {
    resize();
    if (w < 16 || h < 16) {
      requestAnimationFrame(boot);
      return;
    }
    last = 0;
    nextAt = performance.now() + 400;
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(boot);
})();
